package tetris;

public class Komponenta04 extends Komponenta
{

	private int pocetOtoceni;

	public Komponenta04()
	{
		super();
		int[] poloha =
		{ 5, 5, 4 };
		setPoloha(poloha);
		int[] rozmer =
		{ 0, 2, 2 };
		setRozmer(rozmer);
	}

	@Override
	public void otoc()
	{
		if (daSaOtocit())
		{
			pocetOtoceni++;
			switch (pocetOtoceni % 2)
			{
			case 1:
			{
				int[] rozmer =
				{ 1, 2, 1 };
				setRozmer(rozmer);
				int[] poloha =
				{ getPolohaI(0), getPolohaI(1), getPolohaI(2) + 2 };
				setPoloha(poloha);
				// setPozicia(getPozicia() - 1);
				break;
			}
			case 0:
			{
				int[] rozmer =
				{ 0, 2, 2 };
				setRozmer(rozmer);
				int[] poloha =
				{ getPolohaI(0), getPolohaI(1), getPolohaI(2) - 2 };
				setPoloha(poloha);
				// setPozicia(getPozicia() + 1);
			}
			}
		}
	}
}
