package tetris;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.Timer;

public class Posluchac implements KeyListener
{
	Komponenta k;
	Plocha plocha;
	boolean nieJePauza;
	Timer casovac;

	public Posluchac(Komponenta k, Plocha plocha, Timer casovac, boolean nieJePauza)
	{
		this.k = k;
		this.plocha = plocha;
		this.nieJePauza = nieJePauza;
		this.casovac = casovac;
	}

	@Override
	public void keyPressed(KeyEvent e)
	{
		int key = e.getKeyCode();

		if (key == KeyEvent.VK_LEFT && nieJePauza)
		{
			k.vymaz();
			k.posunDolava();
			k.zobraz();
			plocha.repaint();
		}

		if (key == KeyEvent.VK_RIGHT && nieJePauza)
		{
			k.vymaz();
			k.posunDoprava();
			k.zobraz();
			plocha.repaint();
		}

		if (key == KeyEvent.VK_DOWN && nieJePauza)
		{
			k.vymaz();
			k.posunDole();
			k.zobraz();
			plocha.repaint();
		}

		if (key == KeyEvent.VK_UP && nieJePauza)
		{
			k.vymaz();
			k.otoc();
			k.zobraz();
			plocha.repaint();
		}
		if (key == KeyEvent.VK_SPACE)
		{
			if (nieJePauza)
			{
				casovac.stop();
			} else
			{
				casovac.start();
			}
			nieJePauza = !nieJePauza;
		}
	}

	@Override
	public void keyReleased(KeyEvent e)
	{

	}

	@Override
	public void keyTyped(KeyEvent e)
	{

	}
}
