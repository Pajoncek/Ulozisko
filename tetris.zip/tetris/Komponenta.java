package tetris;

public abstract class Komponenta
{
	private int pozicia;
	private int[] poloha = new int[3];
	private int[] rozmer = new int[3];

	public Komponenta()
	{
	}
	public int getPozicia()
	{
		return pozicia;
	}

	public void setPozicia(int pozicia)
	{
		this.pozicia = pozicia;
	}

	public void setPoloha(int[] poloha)
	{
		this.poloha = poloha;
	}

	public void setRozmer(int[] rozmer)
	{
		this.rozmer = rozmer;
	}

	public int getPolohaI(int i)
	{
		return poloha[i];
	}

	public boolean mozeDoprava()
	{
		boolean podmienka = true;
		for (int i = 0; i < 3; i++)
		{
			if (rozmer[i] > 0)
			{
				if ((poloha[i] + rozmer[i]) == 12 || PlochaSet.plocha[poloha[i] + rozmer[i]][pozicia + i])
				{
					podmienka = false;
					break;
				}
			}
		}
		return podmienka;
	}

	public boolean mozeDolava()
	{
		boolean podmienka = true;
		for (int i = 0; i < 3; i++)
		{
			if (rozmer[i] > 0)
			{
				if ((poloha[i]) == 0 || PlochaSet.plocha[poloha[i] - 1][pozicia + i])
				{
					podmienka = false;
					break;
				}
			}
		}
		return podmienka;
	}

	public boolean mozeDole()
	{
		boolean podmienka = true;
		if (rozmer[2] > 0)
		{
			if (poloha[0] < poloha[1] && rozmer[0] > 0)
			{
				for (int i = poloha[0]; i < poloha[1]; i++)
				{
					if (PlochaSet.plocha[i][pozicia + 1])
					{
						podmienka = false;
						break;
					}
				}
			}
			if (poloha[1] < poloha[2])
			{
				for (int i = poloha[1]; i < poloha[2]; i++)
				{
					if (PlochaSet.plocha[i][pozicia + 2])
					{
						podmienka = false;
						break;
					}
				}
			}
			if ((poloha[0] + rozmer[0]) > (poloha[1] + rozmer[1]) && rozmer[0] > 0)
			{
				for (int i = (poloha[1] + rozmer[1]); i < (poloha[0] + rozmer[0]); i++)
				{
					if (PlochaSet.plocha[i][pozicia + 1])
					{
						podmienka = false;
						break;
					}
				}
			}
			if ((poloha[1] + rozmer[1]) > (poloha[2] + rozmer[2]))
			{
				for (int i = (poloha[2] + rozmer[2]); i < (poloha[1] + rozmer[1]); i++)
				{
					if (PlochaSet.plocha[i][pozicia + 2])
					{
						podmienka = false;
						break;
					}
				}
			}
			for (int i = poloha[2]; i < (poloha[2] + rozmer[2]); i++)
			{
				if (PlochaSet.plocha[i][pozicia + 3])
				{
					podmienka = false;
					break;
				}
			}
			if (pozicia == 16)
			{
				podmienka = false;
			}

		} else
		{
			for (int i = poloha[1]; i < (poloha[1] + rozmer[1]); i++)
			{
				if (PlochaSet.plocha[i][pozicia + 2])
				{
					podmienka = false;
					break;
				}
			}
			if (pozicia == 17)
			{
				podmienka = false;
			}
		}
		return podmienka;
	}

	public void posunDoprava()
	{
		if (mozeDoprava())
		{
			for (int i = 0; i < 3; i++)
			{
				poloha[i]++;
			}
		}
	}

	public void posunDolava()
	{
		if (mozeDolava())
		{
			for (int i = 0; i < 3; i++)
			{
				poloha[i]--;
			}
		}
	}

	public void posunDole()
	{
		if (mozeDole())
		{
			pozicia++;
		}
	}

	public void zobraz()
	{
		for (int i = 0; i < 3; i++)
		{
			if (rozmer[i] > 0)
			{
				for (int j = poloha[i]; j < (poloha[i] + rozmer[i]); j++)
				{
					PlochaSet.plocha[j][pozicia + i] = true;
				}
			}
		}
	}

	public void vymaz()
	{
		for (int i = 0; i < 3; i++)
		{
			if (rozmer[i] > 0)
			{
				for (int j = poloha[i]; j < (poloha[i] + rozmer[i]); j++)
				{
					PlochaSet.plocha[j][pozicia + i] = false;
				}
			}
		}
	}

	public boolean daSaOtocit()
	{
		boolean podmienka = true;

		if ((rozmer[0] > 0 && !mozeDolava()) || (rozmer[0] == rozmer[1] && rozmer[1] == rozmer[2] && !mozeDoprava()))
		{
			podmienka = false;
		}
		if (!mozeDole())
		{
			podmienka = false;
		}
		return podmienka;
	}

	public abstract void otoc();

}
