package tetris;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JComponent;

public class Plocha extends JComponent
{
	private static final long serialVersionUID = 1133575261058151421L;

	@Override
	protected void paintComponent(Graphics grafickyKontext)
	{
		Graphics2D g2 = (Graphics2D) grafickyKontext;
		for (int i = 0; i < 12; i++)
		{
			for (int j = 0; j < 20; j++)
			{
				if (PlochaSet.plocha[i][j])
				{
					g2.fillRect(i * 20 + 1, j * 20 + 63, 19, 19);
				}
			}
		}
		g2.drawLine(0, 62, 275, 62);
	}
}
