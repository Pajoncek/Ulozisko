package tetris;

public class Komponenta03 extends Komponenta
{
	private int pocetOtoceni;

	public Komponenta03()
	{
		super();
		int[] poloha =
		{ 5, 4, 4 };
		setPoloha(poloha);
		int[] rozmer =
		{ 0, 1, 3 };
		setRozmer(rozmer);
	}

	@Override
	public void otoc()
	{
		if (daSaOtocit())
		{
		pocetOtoceni++;
		switch (pocetOtoceni % 4)
		{
		case 1:
		{
			int[] rozmer =
			{ 2, 1, 1 };
			setRozmer(rozmer);
			int[] poloha =
			{ getPolohaI(0), getPolohaI(1) + 1, getPolohaI(2) + 1 };
			setPoloha(poloha);
			// setPozicia(getPozicia() - 1);
			break;
		}
		case 2:
		{
			int[] rozmer =
			{ 0, 3, 1 };
			setRozmer(rozmer);
			int[] poloha =
			{ getPolohaI(0), getPolohaI(1) - 1, getPolohaI(2) + 1 };
			setPoloha(poloha);
			// setPozicia(getPozicia() + 1);
			break;
		}
		case 3:
		{
			int[] rozmer =
			{ 1, 1, 2 };
			setRozmer(rozmer);
			int[] poloha =
			{ getPolohaI(0) + 1, getPolohaI(1) + 2, getPolohaI(2) - 1 };
			setPoloha(poloha);
			// setPozicia(getPozicia() - 1);
			break;
		}
		case 0:
		{
			int[] rozmer =
			{ 0, 1, 3 };
			setRozmer(rozmer);
			int[] poloha =
			{ getPolohaI(0) - 1, getPolohaI(1) - 2, getPolohaI(2) - 1 };
			setPoloha(poloha);
			// setPozicia(getPozicia() + 1);
		}
		}
	}
	}

}
