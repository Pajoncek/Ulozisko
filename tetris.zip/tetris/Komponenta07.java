package tetris;

public class Komponenta07 extends Komponenta
{

	private int pocetOtoceni;

	public Komponenta07()
	{
		super();
		int[] poloha =
		{ 5, 4, 5 };
		setPoloha(poloha);
		int[] rozmer =
		{ 0, 3, 0 };
		setRozmer(rozmer);
	}

	@Override
	public void otoc()
	{
		if (daSaOtocit())
		{
			pocetOtoceni++;
			switch (pocetOtoceni % 2)
			{
			case 1:
			{
				int[] rozmer =
				{ 1, 1, 1 };
				setRozmer(rozmer);
				int[] poloha =
				{ getPolohaI(0), getPolohaI(1) + 1, getPolohaI(2) };
				setPoloha(poloha);
				// setPozicia(getPozicia() - 1);
				break;
			}
			case 0:
			{
				int[] rozmer =
				{ 0, 3, 0 };
				setRozmer(rozmer);
				int[] poloha =
				{ getPolohaI(0), getPolohaI(1) - 1, getPolohaI(2) };
				setPoloha(poloha);
				// setPozicia(getPozicia() + 1);
			}
			}
		}
	}
}
