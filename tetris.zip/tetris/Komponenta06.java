package tetris;

public class Komponenta06 extends Komponenta
{

	public Komponenta06()
	{
		super();
		int[] poloha =
		{ 5, 5, 5 };
		setPoloha(poloha);
		int[] rozmer =
		{ 0, 2, 2 };
		setRozmer(rozmer);
	}
	@Override
	public void otoc()
	{

	}

}
