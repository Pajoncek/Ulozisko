package tetris;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

public class Tetris
{
	static void sleep(int oneskorenie)
	{
		try
		{
			TimeUnit.MILLISECONDS.sleep(oneskorenie);
		} catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		JFrame okno = new JFrame();
		final int SIRKA_OKNA = 275;
		final int VYSKA_OKNA = 480;
		int oneskorenie = 500;
		int level = 1;
		boolean podmienka = true;
		boolean nieJePauza = true;

		Plocha plocha = new Plocha();
		JLabel skore = new JLabel();
		JLabel levely = new JLabel();
		Font font = new Font("Font", 1, 20);

		skore.setFont(font);
		skore.setText("SKORE:            " + PlochaSet.pocetRiadkov * 100);

		levely.setFont(font);
		levely.setText("LEVEL:             " + level);

		okno.setSize(SIRKA_OKNA, VYSKA_OKNA);
		okno.setResizable(false);
		okno.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		skore.setSize(200, 25);
		skore.setLocation(10, 5);

		levely.setSize(200, 25);
		levely.setLocation(10, 30);

		plocha.setSize(255, 420);
		plocha.setLocation(0, 0);

		okno.add(skore);
		okno.add(levely);
		okno.add(plocha);
		plocha.setEnabled(true);

		okno.setVisible(true);
		okno.setLocationRelativeTo(null);

		Color farba = Color.lightGray;

		plocha.setForeground(farba);

		// intro
		PlochaSet.intro();
		plocha.repaint();
		sleep(1000);

		for (int i = 1; i < 4; i++)
		{
			PlochaSet.plochaReset();
			plocha.repaint();
			switch (i)
			{
			case 1:
				farba = Color.gray;
				break;
			case 2:
				farba = Color.darkGray;
				break;
			case 3:
				farba = Color.black;
			}
			plocha.setForeground(farba);
			sleep(400);
			PlochaSet.intro();
			plocha.repaint();
			sleep(500);
		}

		sleep(300);

		// resetovanie hracej plochy
		PlochaSet.plochaReset();

		okno.setSize(SIRKA_OKNA - 20, VYSKA_OKNA);

		do
		{
			Komponenta k;

			// generovanie nahodnej komponenty
			int nahodneCislo = (int) (Math.random() * 7);

			if (nahodneCislo == 0)
			{
				k = new Komponenta01();
			} else if (nahodneCislo == 1)
			{
				k = new Komponenta02();
			} else if (nahodneCislo == 2)
			{
				k = new Komponenta03();
			} else if (nahodneCislo == 3)
			{
				k = new Komponenta04();
			} else if (nahodneCislo == 4)
			{
				k = new Komponenta05();
			} else if (nahodneCislo == 5)
			{
				k = new Komponenta06();
			} else
			{
				k = new Komponenta07();
			}

			// casovac
			class TimerListener implements ActionListener
			{
				@Override
				public void actionPerformed(ActionEvent e)
				{
					k.vymaz();
					k.posunDole();
					k.zobraz();
					plocha.repaint();
				}
			}

			ActionListener timerListener = new TimerListener();
			Timer casovac = new Timer(oneskorenie, timerListener);

			k.zobraz();
			casovac.start();
			Posluchac posluchac = new Posluchac(k, plocha, casovac, nieJePauza);
			okno.addKeyListener(posluchac);

			do
			{
				sleep(50);
			} while (k.mozeDole());

			sleep(oneskorenie);

			casovac.stop();
			okno.removeKeyListener(posluchac);
			PlochaSet.vymazRiadky();
			plocha.repaint();

			String medzera = "";
			if (PlochaSet.pocetRiadkov == 0)
			{
				medzera = "            ";
			} else if (PlochaSet.pocetRiadkov < 10)
			{
				medzera = "        ";
			} else if (PlochaSet.pocetRiadkov < 100)
			{
				medzera = "      ";
			} else if (PlochaSet.pocetRiadkov < 100)
			{
				medzera = "    ";
			} else if (PlochaSet.pocetRiadkov < 1000)
			{
				medzera = "  ";
			}

			if (PlochaSet.pocetRiadkov < 7)
			{
				level = 1;
				oneskorenie = 500;
			} else if (PlochaSet.pocetRiadkov < 15)
			{
				level = 2;
				oneskorenie = 400;
			} else if (PlochaSet.pocetRiadkov < 25)
			{
				level = 3;
				oneskorenie = 320;
			} else if (PlochaSet.pocetRiadkov < 40)
			{
				level = 4;
				oneskorenie = 240;
			} else if (PlochaSet.pocetRiadkov < 60)
			{
				level = 5;
				oneskorenie = 180;
			} else if (PlochaSet.pocetRiadkov < 85)
			{
				level = 6;
				oneskorenie = 130;
			} else if (PlochaSet.pocetRiadkov < 120)
			{
				level = 7;
				oneskorenie = 100;
			}

			if (!PlochaSet.daSaVlozit())
			{
				PlochaSet.plochaReset();
				medzera = "            ";
				level = 1;
				oneskorenie = 500;
				plocha.repaint();
			}

			skore.setText("SKORE:" + medzera + PlochaSet.pocetRiadkov * 100);
			levely.setText("LEVEL:             " + level);
			okno.repaint();

		} while (podmienka);

	}
}