package tetris;

public class PlochaSet
{
	static boolean[][] plocha = new boolean[13][20];
	static int pocetRiadkov;

	static void vymazRiadky()
	{
		for (int i = 2; i < 20; i++)
		{
			int pocetTrue = 0;
			for (int j = 0; j < 12; j++)
			{
				if (plocha[j][i])
				{
					pocetTrue++;
				}
				if (pocetTrue == 12)
				{
					for (int k = i; k > 0; k--)
					{
						for (int l = 0; l < 12; l++)
						{
							plocha[l][k] = plocha[l][k - 1];
						}
					}
					pocetRiadkov++;
				}
			}
		}
	}

	static boolean daSaVlozit()
	{
		boolean podmienka = true;
		for (int i = 0; i < 12; i++)
		{
			if (plocha[i][1] || plocha[i][2])
			{
				podmienka = false;
				break;
			}
		}
		return podmienka;
	}

	static void plochaReset()
	{
		for (int i = 0; i < 12; i++)
		{
			for (int j = 0; j < 20; j++)
			{
				plocha[i][j] = false;
			}
		}
		pocetRiadkov = 0;
	}

	static void intro()
	{
		plocha[1][2] = true;
		plocha[2][2] = true;
		plocha[3][2] = true;
		plocha[5][2] = true;
		plocha[6][2] = true;
		plocha[7][2] = true;
		plocha[9][2] = true;
		plocha[10][2] = true;
		plocha[11][2] = true;
		plocha[2][3] = true;
		plocha[5][3] = true;
		plocha[10][3] = true;
		plocha[2][4] = true;
		plocha[5][4] = true;
		plocha[6][4] = true;
		plocha[7][4] = true;
		plocha[10][4] = true;
		plocha[2][5] = true;
		plocha[5][5] = true;
		plocha[10][5] = true;
		plocha[2][6] = true;
		plocha[5][6] = true;
		plocha[6][6] = true;
		plocha[7][6] = true;
		plocha[10][6] = true;
		plocha[2][8] = true;
		plocha[3][8] = true;
		plocha[4][8] = true;
		plocha[6][8] = true;
		plocha[8][8] = true;
		plocha[9][8] = true;
		plocha[10][8] = true;
		plocha[2][9] = true;
		plocha[4][9] = true;
		plocha[6][9] = true;
		plocha[8][9] = true;
		plocha[2][10] = true;
		plocha[3][10] = true;
		plocha[6][10] = true;
		plocha[8][10] = true;
		plocha[9][10] = true;
		plocha[10][10] = true;
		plocha[2][11] = true;
		plocha[4][11] = true;
		plocha[6][11] = true;
		plocha[10][11] = true;
		plocha[2][12] = true;
		plocha[4][12] = true;
		plocha[6][12] = true;
		plocha[8][12] = true;
		plocha[9][12] = true;
		plocha[10][12] = true;
	}
}
